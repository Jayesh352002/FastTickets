package com.example.React.Project.Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

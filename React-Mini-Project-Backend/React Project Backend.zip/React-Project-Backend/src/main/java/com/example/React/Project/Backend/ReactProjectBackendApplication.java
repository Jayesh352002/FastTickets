package com.example.React.Project.Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactProjectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactProjectBackendApplication.class, args);
	}

}
